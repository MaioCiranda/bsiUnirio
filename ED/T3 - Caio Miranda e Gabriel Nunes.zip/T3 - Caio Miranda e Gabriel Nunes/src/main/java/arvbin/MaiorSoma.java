package arvbin;

public class MaiorSoma {
    public final String caminho;
    public final int valor;

    public MaiorSoma(String caminho, int valor) {
        this.caminho = caminho;
        this.valor = valor;
    }
}
