package main;

import interpretador.Interpretador;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String [] args) {
        if (args.length != 1) {
            System.out.println("Use: java -jar Interpretador-1.0.0.jar \"path do arquivo\"");
            return;
        }
        List<String> linhas = new ArrayList<>();

        // Lê o arquivo, linha por linha e armazena na lista
        try (var input = new BufferedReader(new FileReader(args[0]))) {

            for (;;) {
                var linha = input.readLine();

                if (linha == null)
                    break;
                linhas.add(linha);
            }
        }
        catch(IOException e) {
            linhas.clear();
            System.out.printf("Erro na leitura do arquivo '%s': %s\n", args[0], e.getMessage());
        }

        if (! linhas.isEmpty()) {
            System.out.printf("Processando arquivo '%s'\n", args[0]);

            var interpretador = new Interpretador();

            interpretador.processa(linhas);
        }
    }
}
