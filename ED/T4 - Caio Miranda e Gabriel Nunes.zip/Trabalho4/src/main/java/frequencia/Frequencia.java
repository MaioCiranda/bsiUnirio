package frequencia;
import arvbin.AVL;
import heap.Heap;
import hash.Hash;
import heap.TipoHeap;


import java.io.*;
import java.text.Collator;
import java.util.Comparator;
import java.util.Locale;
import java.util.function.Function;

public class Frequencia {

    private Hash excluidas;
    private AVL<PalavraFrequencia, String> alfa;
    Collator collator = Collator.getInstance(new Locale("pt", "PT"));

    //cd = Crescente ou Decrescente; af = Alfabética ou frequência
    public Frequencia(String textoPath, String listaExclusaoPath, char af, char cd) {
        File arquivo = new File(textoPath);
        File arquivo2 = new File(listaExclusaoPath);
        if (!arquivo.exists()) {
            System.out.println("Arquivo de texto não existe!");
            return;
        } else if (!arquivo2.exists()) {
            System.out.println("Arquivo de exclusões não existe!");
            return;
        }
        if (arquivo.length() == 0) {
            System.out.println("Arquivo de texto está vazio!");
            return;
        }
        if ((Character.toLowerCase(af) == 'a' || Character.toLowerCase(af) == 'f') &&
                (Character.toLowerCase(cd) == 'c' || Character.toLowerCase(cd) == 'd'))
        {
            collator.setStrength(Collator.PRIMARY);
            lerExcluidas(listaExclusaoPath);
            lerPalavras(textoPath);
            printarPalavras(af,cd);
        }
        else System.out.println("Insira \'a\' ou \'f\' para ordenar as palavras" +
                "por ordem alfabética ou de frequência e \'c\' ou \'d\' para ordená-las" +
                "por ordem crescente ou decrescente.");
    }

    public class PalavraFrequencia implements Comparable<PalavraFrequencia> {

        String palavra;
        int frequencia;

        public PalavraFrequencia(String palavra) {
            this.palavra = palavra;
            this.frequencia = 1;
        }

        public String getPalavra() {
            return palavra;
        }

        public int getFrequencia() {
            return frequencia;
        }

        public void incrementaFrequencia() {
            this.frequencia++;
        }

        @Override
        public int compareTo(PalavraFrequencia o) {
            if (this.frequencia == o.frequencia) {
                return this.palavra.compareTo(o.palavra);
            }
            return this.frequencia - o.frequencia;
        }

        @Override
        public String toString() {
            return String.format("%s: %d", this.palavra, this.frequencia);
        }
    }

    public void lerExcluidas (String listaExclusaoPath) {
        excluidas = new Hash();
        // Ler cada caractere da string
        try {
            BufferedReader leitor = new BufferedReader(new FileReader(listaExclusaoPath));
            String a = "";
            int c;
            while (true) {
                try {
                    if (!((c = leitor.read()) != -1)) break;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                //Checar se o caractere é uma letra
                Character ch = (char) c;
                if (!Character.isAlphabetic(ch)) {
                    if (!a.equals("")) {
                        // Caso o caractere não seja uma letra e o construtor de strings não esteja vazio, adicionar palavra.
                        a.toLowerCase();
                        excluidas.insere(a, a);
                        a = "";
                    }
                } // Caso o caractere seja uma letra, adicionar a fila
                else {
                    a = a.concat(ch.toString());
                }
            }
            // Adicionar a última palavra
            if (!a.equals("")) {
                a = a.toLowerCase();
                excluidas.insere(a, a);
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void lerPalavras (String textoPath) {
        try {
            Function<PalavraFrequencia, String> pegaChave = PalavraFrequencia::getPalavra;
            Comparator<String> comparator = (s1, s2) -> collator.compare(s1, s2);

            // Set strength to PRIMARY to ignore accents and case
            alfa = new AVL<>(comparator, pegaChave);

            BufferedReader leitor = new BufferedReader(new FileReader(textoPath));
            String a = "";
            int c;
            while (true) {
                try {
                    if (!((c = leitor.read()) != -1)) break;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                //Checar se o caractere é uma letra
                Character ch = (char) c;
                if (!Character.isAlphabetic(ch)) {
                    if (!a.equals("")) {
                        // Caso o caractere não seja uma letra e a string não esteja vazio, adicionar palavra.
                        a = a.toLowerCase();
                        if (alfa.contemChave(a))
                            alfa.buscar(a).incrementaFrequencia();
                        else if (!excluidas.existe(a))
                            alfa.inserir(new PalavraFrequencia(a));
                        a = "";
                    }
                } // Caso o caractere seja uma letra, adicionar a fila
                else
                    a = a.concat(ch.toString());
            }
            if (!a.equals("")) {
                // Caso o caractere não seja uma letra e a string não esteja vazio, adicionar palavra.
                a = a.toLowerCase();
                if (alfa.contemChave(a))
                    alfa.buscar(a).incrementaFrequencia();
                else if (!excluidas.existe(a))
                    alfa.inserir(new PalavraFrequencia(a));
                a = "";
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void printarPalavras(char af, char cd) {
        if (Character.toLowerCase(cd) == 'c' && Character.toLowerCase(af) == 'a')
            alfa.emOrdem(cont -> System.out.println(cont.getPalavra() + ": " + cont.getFrequencia()));
        else if (Character.toLowerCase(cd) == 'd' && Character.toLowerCase(af) == 'a')
            alfa.emOrdemInvertida(v -> System.out.println(v.getPalavra() + ": " + v.getFrequencia()));
        else {
            //escolhe o tipo de heap pela ordem
            TipoHeap tipoHeap;

            if (Character.toLowerCase(cd) == 'c') tipoHeap = TipoHeap.MIN;
            else tipoHeap = TipoHeap.MAX;
            Function<PalavraFrequencia, Integer> pegaFrequencia = PalavraFrequencia::getFrequencia;
            Heap<PalavraFrequencia, Integer> heap = new Heap<>(tipoHeap, pegaFrequencia);

            while (!alfa.estaVazia()) {
                heap.inserir(alfa.menor());
                alfa.remover(alfa.menor());
            }
            while (!heap.estaVazio()) System.out.println(heap.remover().toString());
        }
    }
}
