package main;

import lista.IListaOrdenada;
import lista.LDEO;
import lista.Ordenacao;

public class Main {

    private  LDEO<Integer> listaInt = new LDEO<>(Ordenacao.ASC, (o1, o2) -> o1-o2);
    private  LDEO<String> listaStr = new LDEO<>(Ordenacao.DESC, (o1, o2) -> o1.compareTo(o2));

    private void testeInt() {

        System.out.println("\nTeste de lista de inteiros ascendente");

        listaInt.inserir(5);

        listaInt.inserir(3);

        listaInt.inserir(8);

        listaInt.inserir(4);
        listaInt.inserir(4);

        listaInt.inserir(3);
        listaInt.inserir(7);

        listaInt.inserir(8);

        listaInt.inserir(12);
        listaInt.inserir(7);
        listaInt.inserir(9);

        listaInt.removerPosicao(4);
		listaInt.inserir(6);

        listaInt.remover(6);
		listaInt.inserir(2);

        listaInt.removerPosicao(9);
		listaInt.inserir(11);

        listaInt.removerPosicao(9);
		listaInt.inserir(13);

        listaInt.removerPosicao(5);
		listaInt.inserir(6);
		
		listaInt.posicao(7);
		listaInt.getItem(0);
		listaInt.contem(2);
		listaInt.quantidade();
		listaInt.iterador();
    }

    private void testeStr() {

        System.out.println("\nTeste de lista de strings descendente");

        listaStr.inserir("Joao");
        listaStr.inserir("Ana");
        listaStr.inserir("Pedro");

        listaStr.inserir("Carlos");
        listaStr.inserir("Marcela");
        listaStr.inserir("Abel");

        listaStr.inserir("Carlos");
        listaStr.inserir("Marcela");
        listaStr.inserir("Abel");
        listaStr.inserir("Sandra");

        listaStr.removerPosicao(4);
		listaStr.inserir("Jorge");

        listaStr.remover("Pedro");
		listaStr.inserir("Leandro");

        listaStr.removerPosicao(5);
		listaStr.inserir("Beatriz");

        listaStr.removerPosicao(0);
		listaStr.inserir("Laura");
		
		listaStr.posicao("Abel");
		listaStr.getItem(0);
		listaStr.contem("Pedro");
		listaStr.quantidade();
		listaStr.iterador();
    }

    private void run() {
        testeInt();
        testeStr();
    }

	public static void main(String[] args) {

        var app = new Main();

        app.run();
	}
}
