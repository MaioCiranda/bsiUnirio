package arvbin;

import iterador.Iterador;
import lista.LSE;
import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Function;

public class AVL<T, K> implements IABB<T, K>, Element {
    private No raiz;
    private int quantidade;
    private final Comparator<K> comparador;
    private final Function<T, K> recuperaChave;

    public AVL() {
        this.comparador = (o1, o2) -> { return ((Comparable<K>) o1).compareTo(o2); };
        this.recuperaChave = (o) -> (K) o;
    }

    public AVL(Comparator<K> comparador, Function<T, K> recuperaChave) {
        this.comparador = comparador;
        this.recuperaChave = recuperaChave;
    }

    @Override
    public void accept(Visitante visitor) {
        visitor.visita(this);
    }

    private class No {
        private T item;
        private int h;
        private No esq;
        private No dir;

        public No (T item) {
            this.item = item;
        }
    }

    public void nivel(int n, Visitante<T> visitante) {
        String s = stringNivel(n, visitante);
        if (s == null)
            System.out.println("Nível não existe.");
        else
            System.out.printf("%d:%s\n", n, s);
    }

    public String stringNivel (int n, Visitante<T> visitante) {
        String s = "";
        if (n >=0)
        {
            No aux = raiz;
            if (altura(aux) >= n)
            {
                if (n == 0)
                {
                    s = visitante.visita(s, raiz.item);
                }
                else
                {
                    s = achaNivel(raiz, n, visitante, s);
                }
            }
            else return null;
        }
        else return null;
        return s;
    }

    public String achaNivel(No no, int n, Visitante<T> visitante, String s) {
        if (no != null)
        {
            if (n == 1)
            {
                if (no.esq != null) s = visitante.visita(s, no.esq.item);
                if (no.dir != null) s = visitante.visita(s, no.dir.item);
            }
            else
            {
                n--;
                s = achaNivel(no.esq, n, visitante, s);
                s = achaNivel(no.dir, n, visitante, s);
            }
        }
        return s;
    }

    public LSE<T> menorCaminho(T a, T b) {
        LSE<T> ca = new LSE<>();
        K chaveA = recuperaChave.apply(a);
        K chaveB = recuperaChave.apply(b);
        if (buscar(chaveA) == null || buscar(chaveB) == null)
        {
            return ca;
        }
        if (a.equals(b))
        {
            ca.inserirInicio(buscar(chaveA));
            return ca;
        }
        No aux = raiz;
        No intermediario = null;
        while (aux != null) {
            int cA = comparador.compare(chaveA, recuperaChave.apply(aux.item));
            int cB = comparador.compare(chaveB, recuperaChave.apply(aux.item));
            if ((cA >= 0 && cB <= 0) || (cA <= 0 && cB >= 0)) {
                intermediario = aux;
                break;
            }
            else if (cA < 0)
                aux = aux.esq;
            else
                aux = aux.dir;
        }
        while (aux != null) {
            int cA = comparador.compare(chaveA, recuperaChave.apply(aux.item));
            ca.inserirInicio(aux.item);
            if (cA == 0)
                break;
            else if (cA < 0)
                aux = aux.esq;
            else
                aux = aux.dir;
        }
        if (recuperaChave.apply(intermediario.item).equals(chaveB)) {
            ca.inserirFim(intermediario.item);
            return ca;
        }
        aux = (comparador.compare(chaveA, chaveB) > 0) ? intermediario.esq : intermediario.dir;
        while (aux != null) {
            int cB = comparador.compare(chaveB, recuperaChave.apply(aux.item));
            ca.inserirFim(aux.item);
            if (cB == 0)
                break;
            else if (cB < 0)
                aux = aux.esq;
            else
                aux = aux.dir;
        }
        return ca;
    }

    public String codigo(T a) {
        String codigo = "";
        K chave = recuperaChave.apply(a);
        if (buscar(chave) == null)
            return null;
        if (comparador.compare(chave, recuperaChave.apply(raiz.item)) == 0)
            return null;
        No aux = raiz;
        while (aux != null) {
            if (comparador.compare(chave, recuperaChave.apply(aux.item)) < 0) {
                codigo = codigo.concat("0");
                aux = aux.esq;
            }
            else if (comparador.compare(chave, recuperaChave.apply(aux.item)) > 0) {
                codigo = codigo.concat("1");
                aux = aux.dir;
            }
            else
                return codigo;
        }
        return null;
    }

    public MaiorSoma maxSoma() {
        int h = raiz.h;
        int somaUltima = 0;
        int somaPenultima = 0;
        Integer maiorUltima = 0;
        Integer maiorPenultima = 0;

        ImpressaoVisitante<Integer> v1 = new ImpressaoVisitante<>();
        int i = 0;
        while (i < 2) {
            String test = stringNivel(h - i, v1);
            String[] split = test.split(" ");
            Integer maiorDoNivel = Integer.parseInt(split[split.length - 1]);
            if (i == 0)
                maiorUltima = maiorDoNivel;
            else
                somaPenultima = maiorDoNivel;

            int soma = 0;
            LSE<T> numeros = menorCaminho(raiz.item,(T) maiorDoNivel);
            Iterador iterador = numeros.iterador();
            while (iterador.temProximo()) {
                soma += (Integer) iterador.proximo();
            }
            if (i == 0)
                somaUltima = soma;
            else
                somaPenultima = soma;
            i++;
        }

        String caminho;
        if (somaUltima > somaPenultima)
            caminho = codigo((T) maiorUltima);
        else
            caminho = codigo((T) maiorPenultima);
        caminho = caminho.replaceAll("0", "E").replaceAll("1", "D");

        return new MaiorSoma(caminho, Math.max(somaUltima, somaPenultima));
    }

    @Override
    public void inserir(T e) {
        raiz = inserir(raiz, e, recuperaChave.apply(e));
    }

    @Override
    public void remover(T e) {
        removerChave(recuperaChave.apply(e));
    }

    @Override
    public void removerChave(K key) {
        raiz = removerChave(raiz, key);
    }

    @Override
    public T buscar(K key) {
        No aux = raiz;

        while (aux != null) {
            // Compara a key do nó que está sendo procurado com a key do nó atual (aux)
            int c = comparador.compare(key, recuperaChave.apply(aux.item));

            if (c == 0)
                // key = aux.key -> achou
                break;
            else if (c < 0)
                // key < aux.key -> busca na esquerda
                aux = aux.esq;
            else
                // key > aux.key -> busca na direita
                aux = aux.dir;
        }

        return aux == null ? null : aux.item;
    }

    @Override
    public boolean contem(T e) {
        return buscar(recuperaChave.apply(e)) != null;
    }

    @Override
    public boolean contemChave(K key) {
        return buscar(key) != null;
    }

    @Override
    public T maior() {
        return maior(raiz);
    }

    @Override
    public T menor() {
        return menor(raiz);
    }

    @Override
    public int quantidade() {
        return quantidade;
    }

    @Override
    public boolean estaVazia() {
        return raiz != null;
    }

    @Override
    public void removeTodos() {
        raiz = null;
        quantidade = 0;
    }

    @Override
    public void emOrdem(Visitante<T> visitante) {
        emOrdem(raiz, visitante);
    }

    @Override
    public void emOrdemInvertida(Visitante<T> visitante) {
        emOrdemInvertida(raiz, visitante);
    }

    private No inserir(No r, T e, K key) {
        if (r == null) {
            // Encontrou a posição
            r = new No(e);
            quantidade++;
        }
        else {
            // Compara a key do nó que está sendo inserido com a key do nó atual (r)
            int c = comparador.compare(key, recuperaChave.apply(r.item));

            if (c < 0) {
                // key < r.key -> insere à esquerda
                r.esq = inserir(r.esq, e, key);
                // Recalcula a altura do nó e verifica o balanceamento (LL ou LR)
                r.h = altura(r);
                if (fb(r) > 1) {
                    if (comparador.compare(key, recuperaChave.apply(r.esq.item)) < 0)
                        r = rotateLL(r);
                    else
                        r = rotateLR(r);
                }
            }
            else if (c > 0) {
                // key > r.key -> insere à direita
                r.dir = inserir(r.dir, e, key);
                // Recalcula a altura do nó e verifica o balanceamento (RR ou RL)
                r.h = altura(r);
                if (fb(r) > 1) {
                    if (comparador.compare(key, recuperaChave.apply(r.dir.item)) > 0)
                        r = rotateRR(r);
                    else
                        r = rotateRL(r);
                }
            }
        }

        return r;
    }

    private No removerChave(No r, K key) {
        if (r == null)
            // key não encontrada -> retorna nulo
            return null;
        else {
            int c = comparador.compare(key, recuperaChave.apply(r.item));

            if (c < 0) {
                // key < r.key -> remove à esquerda
                r.esq = removerChave(r.esq, key);
                // Recalcula a altura do nó e verifica o balanceamento (RR ou RL)
                r.h = altura(r);
                if (fb(r) > 1) {
                    if (altura(r.dir.dir) > altura(r.dir.esq))
                        r = rotateRR(r);
                    else
                        r = rotateRL(r);
                }
            }
            else if (c > 0) {
                // key > r.key -> remove à direita
                r.dir = removerChave(r.dir, key);
                // Recalcula a altura do nó e verifica o balanceamento (LL ou LR)
                r.h = altura(r);
                if (fb(r) > 1) {
                    if (altura(r.esq.esq) > altura(r.esq.dir))
                        r = rotateLL(r);
                    else
                        r = rotateLR(r);
                }
            }
            else {
                // key = r.key -> remove r
                // 1o caso: r é folha
                if (r.esq == null && r.dir == null) {
                    r = null;
                    quantidade--;
                } // 2o caso A: r com apenas um filho à esquerda
                else if (r.esq != null && r.dir == null) {
                    r = r.esq;
                    quantidade--;
                } // 2o caso B: r com apenas um filho à direita
                else if (r.esq == null && r.dir != null) {
                    r = r.dir;
                    quantidade--;
                } // 3o caso: r tem 2 filhos
                else {
                    // Descobre o maior nó da SAE OU o menor nó da SAD (tanto faz!)
                    T m = maior(r.esq);
                    r = removerChave(r, recuperaChave.apply(m));
                    r.item = m;
                }
            }
        }

        return r;
    }

    private T maior(No r) {
        if (r == null)
            return null;

        while (r.dir != null)
            r = r.dir;

        return r.item;
    }

    private T menor(No r) {
        if (r == null)
            return null;

        while (r.esq != null)
            r = r.esq;

        return r.item;
    }

    private void emOrdem(No r, Visitante<T> visitante) {
        if (r == null)
            return;

        emOrdem(r.esq, visitante);
        visitante.visita(r.item);
        emOrdem(r.dir, visitante);
    }

    private void emOrdemInvertida(No r, Visitante<T> visitante) {
        if (r == null)
            return;

        emOrdem(r.dir, visitante);
        visitante.visita(r.item);
        emOrdem(r.esq, visitante);
    }

    private int altura(No r) {
        if (r == null)
            return -1;

        int he = r.esq == null ? -1 : r.esq.h;
        int hd = r.dir == null ? -1 : r.dir.h;

        return Math.max(he, hd) + 1;
    }

    private int fb(No r) {
        int he = r.esq == null ? -1 : r.esq.h;
        int hd = r.dir == null ? -1 : r.dir.h;

        return Math.abs(he - hd);
    }

    private No rotateLL(No r) {
        No no = r.esq;
        r.esq = no.dir;
        no.dir = r;

        r.h = altura(r);
        no.h = altura(no);

        return no;
    }

    private No rotateRR(No r) {
        No no = r.dir;
        r.dir = no.esq;
        no.esq = r;

        r.h = altura(r);
        no.h = altura(no);

        return no;
    }

    private No rotateLR(No r) {
        r.esq = rotateRR(r.esq);
        r = rotateLL(r);

        return r;
    }

    private No rotateRL(No r) {
        r.dir = rotateLL(r.dir);
        r = rotateRR(r);

        return r;
    }

    /**
     * Retorna uma string com os itens da árvore em formato de indentação.
     */
    @Override
    public String toString() {
        StringBuilder buffer = new StringBuilder();

        imprime(raiz, 0, buffer);

        return buffer.toString();
    }

    private void imprime(No r, int nivel, StringBuilder buffer) {
        if (r == null)
            return;

        buffer.append("...".repeat(nivel));

        buffer.append(r.item.toString());
        buffer.append("\n");

        nivel++;

        imprime(r.esq, nivel, buffer);
        imprime(r.dir, nivel, buffer);
    }
}
