package iterador;

public interface Iterador<T> {

	boolean temProximo();
	
	T proximo();
}
