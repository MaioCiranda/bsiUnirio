package interpretador;

import java.sql.Struct;
import java.util.List;
import java.util.Locale;

import lista.Pilha;
import lista.LSE;

public class Interpretador {
    private int qtdLinhas = 0;
    LSE<Variavel> var = new LSE<>();

    private class Variavel {
        private double valor;
        private char letra;
        public Variavel(double valor, char letra) {
            this.valor = valor;
            this.letra = letra;
        }

        public char getLetra() {
            return letra;
        }

        public double getValor() {
            return valor;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Variavel)) return false;
            Variavel v = (Variavel) o;
            return this.letra == v.letra;
        }

        @Override
        public int hashCode() {
            return Character.hashCode(letra);
        }

        @Override
        public String toString() {
            return "Variavel{" +
                    "valor=" + valor +
                    ", letra=" + letra +
                    '}';
        }
    }

    public void processa(List<String> linhas) {
        for (var linha : linhas) {
            qtdLinhas++;
            linha = linha.replaceAll("\\s", "");
            if(!linha.isEmpty()) {
                {
                    if (linha.charAt(0) == '@' && linha.length() == 2 &&
                            encontrar(linha.charAt(1)) != null) {
                        imprimirVariavel(linha, linha.charAt(1));
                    }
                    else {
                        if (linha.split("=").length == 2 && Character.isLetter(linha.charAt(0))
                            && linha.split("=")[0].length() == 1)
                            atribuirVariavel(linha, linha.charAt(0));
                        else if (linha.replaceAll("[@=]", "").length() == linha.length())
                            System.out.printf("Comando inválido (linha %d)\n", qtdLinhas);
                        else
                            System.out.printf("Variável inválida (linha %d)\n", qtdLinhas);
                    }
                }
            }
        }
    }

    private void atribuirVariavel(String linha, char v){
        if (v >= 'a' && v <= 'z')
            v = (char) (v - 32);
        String add = linha.split("=")[1];
        Variavel obj = encontrar(v);

        if (add.charAt(0) != '(' && add.replaceAll("[+\\-*$^]", "").length() != add.length()) {
            System.out.printf("Expressão inválida (linha %d)\n", qtdLinhas);
        }
        else if(add.charAt(0) == '(') {
            if (validarExpressao(add))
                var.inserirInicio(new Variavel(calculoExpres(add), v));
        }
        else {
            if (add.replaceAll("[^0-9.]", "").length() != add.length()
                || add.split(".").length > 2) {
                System.out.printf("Valor inválido (linha %d)\n", qtdLinhas);
            }
            else {
                var.inserirInicio(new Variavel(Double.parseDouble(add), v));
            }
        }
    }

    private boolean validarExpressao (String exp) {
        int abre = 0;
        int fecha = 0;
        int operador = 0;
        for (int i = 0; i < exp.length(); i++) {
            char comp = exp.charAt(i);
            if (comp == '+' || comp == '-' || comp == '*' ||
                comp == '/' || comp == '^' || comp == '$' || comp == '$')
                operador++;
            else if (comp == '(')
                abre++;
            else if (comp == ')')
                fecha++;
            else if (!Character.isAlphabetic(comp)) {
                System.out.printf("Expressão inválida (linha %d)\n", qtdLinhas);
                return false;
            }
        }
        if (abre == fecha && fecha == operador)
            return true;
        System.out.printf("Expressão inválida (linha %d)\n", qtdLinhas);
        return false;
    }

    private double calculoExpres(String exp){
        double res = 0;
        double a;
        double b;
        char operacao = '_';
        Pilha<Double> numeros = new Pilha<>();
        Pilha<Character> operadores = new Pilha<>();
        for (int i = 0; i < exp.length(); i++) {
            char comp = exp.charAt(i);
            if (Character.isAlphabetic(comp)) {
                double numero = encontrar(comp).valor;
                numeros.push(numero);
            }
            else if (comp == '+' || comp == '-' || comp == '*' ||
                    comp == '/' || comp == '^' || comp == '$' || comp == '(') {
                operadores.push(comp);
            }
            else if (comp == ')') {
                operacao = operadores.pop();
                while (operacao != '(') {
                    b = numeros.pop();
                    if (operacao == '$') {
                        res = Math.sqrt(b);
                    } else {
                        a = numeros.pop();
                        res = realizarOperacao(a, b, operacao);
                    }
                    numeros.push(res);
                    operacao = operadores.pop();
                }
            }
        }
        return res;
    }

    private double realizarOperacao (double a, double b, char operacao) {
        if (operacao == '+')
            return a + b;
        if (operacao == '-')
            return a - b;
        if (operacao == '*')
            return a * b;
        if (operacao == '/')
            return a / b;
        if (operacao == '^')
            return Math.pow(a, b);
        return 0;
    }

    private void imprimirVariavel(String linha, char v){
        if(linha.length() != 2 || encontrar(v) == null) {
            System.out.printf("Variável inválida (linha  %d)\n", qtdLinhas);
        }
        else {
            System.out.printf("%.6f\n", encontrar(v).valor);

        }
    }

    private boolean varExiste(char verificador) {
        return var.posicao(new Variavel(0, verificador)) != -1;
    }

    private Variavel encontrar (char v) {
        for (int i = 0; i < qtdLinhas; i++) {
            Variavel atual = var.getItem(i);
            if (atual == null)
                return null;
            if (atual.letra == v)
                return atual;
        }
        return null;
    }

}
