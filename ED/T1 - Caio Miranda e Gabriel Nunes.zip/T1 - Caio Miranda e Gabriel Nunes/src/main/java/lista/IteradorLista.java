package lista;

public interface IteradorLista<T> {

	boolean temProximo();

	boolean hasPrevious();

	T proximo();

	T anterior();
}
