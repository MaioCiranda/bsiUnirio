package lista;

public class Pilha<T> {
    private No head = null;
    private int size = 0;

    private class No {
        private No prox;
        private  T item;

        public No(T item){
            this.prox = null;
            this.item = item;
        }
    }

    public boolean push(T item) {
        No n;

        try {
            n = new No(item);
        }
        catch (Exception e) {
            return false;
        }

        if (head != null)
            n.prox = head;
        head = n;
        size++;
        return true;
    }

    public T pop() {
        if (isEmpty()) return null;

        No aux = head;
        head = head.prox;
        size--;
        return aux.item;
    }

    public T peek() {
        if (isEmpty()) return null;
        return head.item;}

    public boolean isEmpty(){return size == 0;}

    public int size(){return size;}
}