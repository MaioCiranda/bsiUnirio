package arvbin;

public interface Element {
    void accept(Visitante visitor);
}
