package lista;

public enum Ordenacao {ASC, DESC};
