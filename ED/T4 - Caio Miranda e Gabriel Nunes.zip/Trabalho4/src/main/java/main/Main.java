package main;

import frequencia.Frequencia;

public class Main {
    public static void main(String[] args) {
        Frequencia frequencia = new Frequencia("/home/maiociranda/Documentos/BSI/ED/Trabalho4/src/main/java/leroleroti.txt",
                "/home/maiociranda/Documentos/BSI/ED/Trabalho4/src/main/java/exclusoes.txt",
                                        'a', 'c');
    }
}
