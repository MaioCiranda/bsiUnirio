package arvbin;

public class ImpressaoVisitante<T>implements Visitante {

    @Override
    public void visita(Object item){
        System.out.print(item + " ");
    }

    @Override
    public String visita(String s, Object item) {
        s = s.concat(" " + item.toString());
        return s;
    }
}
