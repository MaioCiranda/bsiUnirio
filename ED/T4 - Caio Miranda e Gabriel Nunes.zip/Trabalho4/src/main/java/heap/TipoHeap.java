package heap;

public enum TipoHeap {
    MIN, MAX
}
